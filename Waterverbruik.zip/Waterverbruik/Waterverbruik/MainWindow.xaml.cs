﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Waterverbruik
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            label_amountDue.Visibility = Visibility.Hidden;
            textBlock_amountDue.Visibility = Visibility.Hidden;
        }

        // Variables for calculate button
        int waterConsumption;
        double amountDue_rate1;
        double amountDue_rate2;
        double amountDue_toBePaid;

        private void Label_calculateButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            string text = textBox_waterConsumption.Text; 

            if (text != "Invoer aantal m³" && text != ""
                && !chooseRate.IsSelected)
            {
                waterConsumption = Convert.ToInt16(textBox_waterConsumption.Text);

                amountDue_rate1 = 100.00 + (0.25 * waterConsumption);
                amountDue_rate2 = 75.00 + (0.38 * waterConsumption);

                if (rate0.IsSelected)
                {
                    if (amountDue_rate1 <= amountDue_rate2) { amountDue_toBePaid = amountDue_rate1; }
                    else { amountDue_toBePaid = amountDue_rate2; }
                }
                if (rate1.IsSelected) { amountDue_toBePaid = amountDue_rate1; }
                if (rate2.IsSelected) { amountDue_toBePaid = amountDue_rate2; }

                textBlock_amountDue.Text = amountDue_toBePaid.ToString("C", CultureInfo.GetCultureInfo("nl-NL"));

                label_amountDue.Visibility = Visibility.Visible;
                textBlock_amountDue.Visibility = Visibility.Visible;
            }
            else
            {
                if (text == "Invoer aantal m³" || text == "")
                {
                    MessageBox.Show("Voer het waterverbruik in.", "Geen onvoer");
                }
                else
                {
                    if (chooseRate.IsSelected)
                    {
                        MessageBox.Show("Selecteer het tarieftype.", "Geen invoer");
                    }
                }
            }     
        }

        private void TextBox_waterConsumption_GotMouseCapture(object sender, MouseEventArgs e)
        {
            string text = textBox_waterConsumption.Text;

            if (text == "Invoer aantal m³")
            {
                text = "";
                textBox_waterConsumption.Text = text;
                textBox_waterConsumption.Foreground = new SolidColorBrush(Colors.Black);
            }

            textBox_waterConsumption.CaretBrush = new SolidColorBrush(Colors.Black);
        }

        private void TextBox_waterConsumption_LostFocus(object sender, RoutedEventArgs e)
        {
            string text = textBox_waterConsumption.Text;

            if (text == "")
            {
                text = "Invoer aantal m³";
                textBox_waterConsumption.Text = text;
                textBox_waterConsumption.Foreground = new SolidColorBrush(Colors.DarkGray);
            }

            textBox_waterConsumption.CaretBrush = new SolidColorBrush(Colors.White);
        }

        private void ComboBox_rate_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!chooseRate.IsSelected)
            {
                comboBox_rate.Foreground = new SolidColorBrush(Colors.Black);
            }
            else { } // Ignore

            textBox_waterConsumption.CaretBrush = new SolidColorBrush(Colors.White);
        }

        private void TextBox_waterConsumption_TextChanged(object sender, TextChangedEventArgs e)
        {
            string text = textBox_waterConsumption.Text;
            string allowedChars = "0123456789";
            char[] arrayOfAllowedChars = allowedChars.ToCharArray();

            if (text != "Invoer aantal m³" && text != "")
            {
                foreach (char c in text)
                {
                    if (!arrayOfAllowedChars.Contains(c))
                    {
                        textBox_waterConsumption.Text = text.Remove(text.Length - 1, 1);
                        textBox_waterConsumption.SelectionStart = textBox_waterConsumption.Text.Length;
                        MessageBox.Show("In dit veld kunt u alleen getallen (zonder decimalen) invoeren.", "Ongeldige invoer");
                    }
                }

                waterConsumption = Convert.ToInt32(text);
                if (waterConsumption > 5000)
                {
                    textBox_waterConsumption.Text = text.Remove(text.Length - 1, 1);
                    textBox_waterConsumption.SelectionStart = textBox_waterConsumption.Text.Length;
                    MessageBox.Show("Als waterverbruik kunt u maximaal 5000 m³ invoeren.", "Ongeldige invoer");
                }
            }
        }
    }
}
