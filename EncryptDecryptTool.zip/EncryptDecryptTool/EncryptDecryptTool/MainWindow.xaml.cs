﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Caesar_Salad_Encryption
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            textBlock_backToMainMenu.Visibility = Visibility.Collapsed;
            label_chooseEncryptDecrypt.Visibility = Visibility.Visible;
            label_button1.Visibility = Visibility.Visible;
            label_button2.Visibility = Visibility.Visible;
            label_button3.Visibility = Visibility.Collapsed;
            label_button4.Visibility = Visibility.Collapsed;
            image_startscreen.Visibility = Visibility.Visible;
            label_textBoxInput.Visibility = Visibility.Collapsed;
            label_textBoxKey.Visibility = Visibility.Collapsed;
            label_textBoxOutput.Visibility = Visibility.Collapsed;
            textBox_input.Visibility = Visibility.Collapsed;
            textBox_key.Visibility = Visibility.Collapsed;
            textBox_output.Visibility = Visibility.Collapsed;
        }

        string encryptionKey = "";

        public void MakeStringOfChars(int[] arrayOfEncryptedChars, TextBox textBox)
        {
            var stringBuilder = new StringBuilder();

            for (int i = 0; i < (arrayOfEncryptedChars.Length); i++)
            {
                stringBuilder.Append(arrayOfEncryptedChars[i] + "-");
            }
           
            string text = stringBuilder.ToString();
            text = text.Remove(text.Length - 1); // removes last '-'
            textBox.Text = text; 
        }

        // CAESAR SALAD ENCRYPTION
        // Creates blocks of characters, each block with its own unique encryption

        // Create Caesar Salad 
        private void EncryptionCaesarSalad(string text)
        {
            List<int> listOfEncryptedChars = new List<int>();
            foreach (char c in text)
            {
                // Simple ASCII Encoding (just cast a character to an int)
                listOfEncryptedChars.Add(c);
            }

            // Get the number of characters of the text
            int numOfChars = text.Length;

            // Standard blocklength in terms of number of characters
            int blockLength = 20;

            // Extend blocklength if number of characters > 400, 
            // to reduce blocklength and the length of the encryption key to a maximum
            if (numOfChars > 400)
            {
                blockLength = 20 + ((numOfChars - 100) / 20);
            }

            // Calculate the total number of character blocks in the text
            int numOfCharBlocks = 1;
            if (blockLength > numOfChars)
            {
                numOfCharBlocks += numOfChars / blockLength;
            }

            // Create charBlocks and add blocks to a list
            List<string> charBlocks = new List<string>();
            for (int i = 0; i < numOfChars; i++)
            {
                if (i % blockLength == 0)
                {
                    int startIndex = i;
                    string sub = text.Substring(startIndex);
                    charBlocks.Add(sub);
                }
            }

            // Create a random number for each charBlock and add this number to list
            Random random = new Random();
            int randomNumber;
            List<int> listOfRandomNumbers = new List<int>();
            foreach (string sub in charBlocks)
            {
                randomNumber = random.Next(0, 255);  // random number to be added to bytes from plaintext

                // Add numbers to list
                listOfRandomNumbers.Add(randomNumber);
            }

            // Encrypt each characters integer by adding the random number of its charBlock
            for (int i = 0; i < listOfEncryptedChars.Count; i++)
            {
                int blockNumber = i / blockLength;
                int c = Convert.ToInt32(listOfEncryptedChars[i]);
                c += listOfRandomNumbers[blockNumber];

                if (c > 255)
                {
                    c -= 256;  // a byte can hold values in the range of 0 to 255
                }
                else { } // Ignore

                // For extra encryption of the characters integers the following algorithm is used
                c = (c + 7) * 777 * 777;

                // Add character integers to a list
                listOfEncryptedChars[i] = c; 
            }

            // Convert list to array
            int[] arrayOfEncryptedChars = listOfEncryptedChars.ToArray();

            // Make string of the array of encrypted characters and show in textbox 
            MakeStringOfChars(arrayOfEncryptedChars, textBox_output);

            // Make the encryption key: 
            // A string is created of the listed random numbers and the extra encryption algorithm is added 
            string randomNumbers = "";
            for (int i = 0; i < listOfRandomNumbers.Count; i++)
            {
                listOfRandomNumbers[i] = (listOfRandomNumbers[i] + 7) * 777 * 777;
                randomNumbers += listOfRandomNumbers[i].ToString() + "-";
            }
            randomNumbers = randomNumbers.Remove(randomNumbers.Length - 1);  // to prevent that the key ends with '-'

            // Add extra encryption algorithm to blockLength
            blockLength = (blockLength + 7) * 777 * 777;

            // Make definitive encryption key
            encryptionKey = blockLength.ToString() + "-" + randomNumbers;
            
            // Print key to screen
            textBox_key.Text = encryptionKey;
        }

        // Decrypt Caesar Salad
        private void DecryptionCaesarSalad(string encryptedText, string encryptionKey)
        {
            // Create list of encrypted character strings
            List<string> listOfNumbersToBeDecrypted = new List<string>();
            encryptedText = encryptedText.Replace("-", " ");                 // first remove the commas, using replace
            listOfNumbersToBeDecrypted = encryptedText.Split(' ').ToList();  // split string, with spaces as delimiter

            // Number of characters
            int numOfChars = listOfNumbersToBeDecrypted.Count;

            // Get list of encryption key elements (strings)
            List<string> keyElements = new List<string>();
            encryptionKey = encryptionKey.Replace("-", " ");   // first remove the commas, using replace
            keyElements = encryptionKey.Split(' ').ToList();   // split string, with spaces as delimiter

            // Convert keyElements to integers
            List<int> charKeys = new List<int>();
            foreach (string element in keyElements)
            {
                charKeys.Add(Convert.ToInt32(element));
            }

            // Decrypt character keys, by using the encryption/decryption algorithm
            for (int i = 0; i < charKeys.Count; i++)
            { 
                charKeys[i] = (charKeys[i] / 777 / 777) - 7;
            }

            // Get the blocklength (number of characters per block) and the total number of charBlocks 
            int blockLength = charKeys[0];
            int numOfCharBlocks = charKeys.Count - 1;
             
            // Remove blocklength from list with charKeys, because it's not a charKey
            charKeys.RemoveAt(0);

            // Get character blocks (substrings of encrypted text)
            List<string> charBlocks = new List<string>();
            for (int i = 0; i < numOfChars; i++)
            {
                if (i % blockLength == 0)
                {
                    int startIndex = i;
                    string sub = encryptedText.Substring(startIndex);
                    charBlocks.Add(sub);
                }
            }
                    
            // Convert strings to integers, and the integers to characters
            List<int> listOfIntegers = new List<int>();
            foreach (string n in listOfNumbersToBeDecrypted)
            {
                int i = Convert.ToInt32(n);
                listOfIntegers.Add(i);
            }

            // First part of decryption of the encrypted text
            for (int i = 0; i < listOfIntegers.Count; i++)
            {
                listOfIntegers[i] = (listOfIntegers[i] / 777 / 777) - 7;
            }
            
            // Second part of decryption of the encrypted text, using the decrypted encryption keys
            List<char> listOfDecryptedChars = new List<char>();
            int count = 0;
            for (int i = 0; i < numOfChars; i++)
            {
                if (i % blockLength == 0 && i > 0)  
                {
                    count += 1;
                }

                int charNumber = listOfIntegers[i];
                charNumber -= Convert.ToInt32(charKeys[count]);
                if (charNumber < 0)
                {
                    charNumber += 256;  // a byte can hold values in the range of 0 to 255
                }
                else { }  // Ignore

                // Add decrypted chars to list
                listOfDecryptedChars.Add((char)charNumber);
            }

            // Make a string of the decrypted array of characters and show in textbox
            foreach (char c in listOfDecryptedChars)
            {
                textBox_output.Text += c;
            }
            // Set startindex of textbox at 14, to remove the 'Please wait...' text.
            textBox_output.Text = textBox_output.Text.Substring(14);  
        }
        
        // BUTTON MOUSEDOWN ACTIONS

        // Status:
        bool encryptionMode = false;
        bool decryptionMode = false;

        // Start text textboxes
        string startText_textBoxInputEncryption = "Type your text here, copy & paste or import from txt-file";
        string startText_textBoxInputDecryption = "Place encrypted text here";

        // Open file method
        private void OpenFileDialog(TextBox textBox)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                DefaultExt = ".txt",
                Filter = "Text document (.txt)|*.txt"
            };

            if (openFileDialog1.ShowDialog() == true)
            {
                StreamReader reader = new StreamReader(openFileDialog1.FileName);
                textBox.Text = File.ReadAllText(openFileDialog1.FileName);
            }

            encryptionSaved = false;
            keySaved = false;
        }

        private void OpenEncryption(TextBox textBox)
        { 
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                Filter = "Caesar Salad Encryption (.cse)|*.cse"
            };

            if (openFileDialog1.ShowDialog() == true)
            {
                StreamReader reader = new StreamReader(openFileDialog1.FileName);
                textBox.Text = File.ReadAllText(openFileDialog1.FileName);
            }

            encryptionSaved = false;
            keySaved = false;
        }

        private void OpenKey(TextBox textBox) 
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                Filter = "Caesar Salad Key (.csk)|*.csk" 
            };

            if (openFileDialog1.ShowDialog() == true)
            {
                StreamReader reader = new StreamReader(openFileDialog1.FileName);
                textBox.Text = File.ReadAllText(openFileDialog1.FileName);
            }

            encryptionSaved = false;
            keySaved = false;
        }

        // Save file method
        private void SaveFileDialog(string text)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog()
            {
                DefaultExt = ".txt",
                Filter = "Text document (.txt)|*.txt",
            };

            if (saveFileDialog1.ShowDialog() == true)
            {
                File.WriteAllText(saveFileDialog1.FileName, text);
            }
        }

        // This method adds ".csk" to key encryption
        bool keySaved = false;
        private void SaveKeyToTxt(string text)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog()
            {
                Filter = "Caesar Salad Key (.csk)|*.csk"
            };

            if (saveFileDialog1.ShowDialog() == true)
            {
                File.WriteAllText(saveFileDialog1.FileName, text);
                keySaved = true;
            }
        }

        // This method add ".cse" to encrypted text
        bool encryptionSaved = false;
        private void SaveEncryptedTextToTxt(string text)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog()
            {
                Filter = "Caesar Salad Encryption (.cse)|*.cse"
            };

            if (saveFileDialog1.ShowDialog() == true)
            {
                File.WriteAllText(saveFileDialog1.FileName, text);
                encryptionSaved = true;
            }
        }

        // This method add ".txt" to encrypted text
        bool decryptionSaved = false;
        private void SaveDecryptedTextToTxt(string text)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog()
            {
                Filter = "Text document (.txt)|*.txt",
            };

            if (saveFileDialog1.ShowDialog() == true)
            {
                File.WriteAllText(saveFileDialog1.FileName, text);
                decryptionSaved = true;
            }
        }

        // Button 1
        private void Label_button1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Encryption mode
            if (encryptionMode == true)
            {
                // Import txt-file to textBoxInput
                if (textBox_input.Text != startText_textBoxInputEncryption && textBox_input.Text != "")
                {
                    MessageBoxResult result =
                    MessageBox.Show("If you import a textfile, the current plaintext in the textbox will be lost. " +
                                    "Are you sure you want to import a file?", "Import txt-file", MessageBoxButton.YesNo);

                    if (result == MessageBoxResult.Yes)
                    {
                        OpenFileDialog(textBox_input);
                        textBox_input.Foreground = new SolidColorBrush(Colors.Black);
                    }
                    else
                    {
                        // Ignore
                    }
                }
                 
                if (textBox_input.Text == startText_textBoxInputEncryption || textBox_input.Text == "")
                {
                    OpenFileDialog(textBox_input);
                    textBox_input.Foreground = new SolidColorBrush(Colors.Black);
                }

            }

            // Decryption mode
            if (decryptionMode == true)
            {
                // Import decrypted txt-file to textBoxInput
                OpenEncryption(textBox_input);
                textBox_input.Foreground = new SolidColorBrush(Colors.Black);
            }

            // No mode (main menu)
            if (encryptionMode == false && decryptionMode == false)
            {
                textBlock_backToMainMenu.Visibility = Visibility.Visible;

                label_chooseEncryptDecrypt.Visibility = Visibility.Collapsed;

                image_startscreen.Visibility = Visibility.Collapsed;

                label_textBoxInput.Visibility = Visibility.Visible;
                label_textBoxInput.Content = "Plaintext:";
                textBox_input.Visibility = Visibility.Visible;
                textBox_input.Text = startText_textBoxInputEncryption;

                label_textBoxKey.Visibility = Visibility.Visible;
                label_textBoxKey.Content = "Key:";
                textBox_key.Visibility = Visibility.Visible;
                textBox_key.Text = "";
                textBox_key.IsReadOnly = true;

                label_textBoxOutput.Visibility = Visibility.Visible;
                label_textBoxOutput.Content = "Ciphertext:";
                textBox_output.Visibility = Visibility.Visible;

                label_button1.Content = "Import txt-file";
                label_button2.Content = "Encrypt text";

                // Status update:
                encryptionMode = true;
            } 
        }

        // Button 2
        private void Label_button2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Encryption mode
            if (encryptionMode == true 
                && textBox_input.Text != startText_textBoxInputEncryption && textBox_input.Text != "")
            {
                // Encrypt plaintext with Caesar Salad Encryption
                string plainText = textBox_input.Text;
                EncryptionCaesarSalad(plainText);

                // Show buttons
                label_button3.Visibility = Visibility.Visible;
                label_button3.Content = "Save key";

                label_button4.Visibility = Visibility.Visible;
                label_button4.Content = "Save encrypted text";

                // Status update
                keySaved = false;
                encryptionSaved = false;
            }

            // Decryption mode
            if (decryptionMode == true
                && textBox_input.Text != startText_textBoxInputEncryption && textBox_input.Text != ""
                && textBox_key.Text != startText_textBoxKey && textBox_key.Text != "")
            {
                // Decrypt
                textBox_output.Text = "Please wait...";

                MessageBoxResult result 
                    = MessageBox.Show
                    ("Depending on the size of the text, decryption may take some time. Do you want to start decrypting now?",
                     "Decryption", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    DecryptionCaesarSalad(textBox_input.Text, textBox_key.Text);

                    label_button4.Visibility = Visibility.Visible;
                    label_button4.Margin = new Thickness(0, 42, 0, 0);
                    label_button4.Content = "Save decrypted text";
                }
                else
                {
                    // Ignore
                }
            }

            // No mode (main menu)
            if (encryptionMode == false && decryptionMode == false)
            {
                textBlock_backToMainMenu.Visibility = Visibility.Visible;

                label_chooseEncryptDecrypt.Visibility = Visibility.Collapsed;

                image_startscreen.Visibility = Visibility.Collapsed;

                label_textBoxInput.Content = "Ciphertext:";
                label_textBoxInput.Visibility = Visibility.Visible;
                textBox_input.Text = "Place encrypted text here";
                textBox_input.Visibility = Visibility.Visible;
                textBox_input.Foreground = new SolidColorBrush(Colors.DimGray);

                label_textBoxKey.Visibility = Visibility.Visible;
                label_textBoxKey.Content = "Key:";
                label_textBoxKey.Visibility = Visibility.Visible;
                textBox_key.Visibility = Visibility.Visible;
                textBox_key.Text = startText_textBoxKey;
                textBox_key.Foreground = new SolidColorBrush(Colors.DimGray);
                textBox_key.IsReadOnly = false;

                label_textBoxOutput.Visibility = Visibility.Visible;
                label_textBoxOutput.Content = "Plaintext after decryption:";
                textBox_output.Visibility = Visibility.Visible;

                label_button1.Content = "Import encrypted text";

                label_button2.Content = "Decrypt text";
                Grid.SetRow(label_button2, 5);
                label_button2.Margin = new Thickness(0, 0, 0, 0);

                label_button3.Visibility = Visibility.Visible;
                label_button3.Content = "Import key";
              
                // Status update:
                decryptionMode = true;
            }
        }

        // Button 3
        private void Label_button3_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Encryption mode
            if (encryptionMode == true)
            {
                // Save key to txt-file
                SaveKeyToTxt(textBox_key.Text);
            }

            // Decryption mode
            if (decryptionMode == true)
            {
                // Import key from txt-file
                OpenKey(textBox_key);
                textBox_key.Foreground = new SolidColorBrush(Colors.Black);

                // Status update
                decryptionSaved = false;
            }
        }

        // Button 4
        private void Label_button4_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Encryption mode
            if (encryptionMode == true)
            {
                // Save encrypted text to txt-file
                SaveEncryptedTextToTxt(textBox_output.Text);
            }

            // Decryption mode
            if (decryptionMode == true)
            {
                // Save decrypted text to txt-file
                SaveDecryptedTextToTxt(textBox_output.Text);
            }
        }


        // MOUSE OVER HOVER EFFECT BUTTONS
        bool mouseHover = false;

        private void ChangeGradientBrush(Label label)
        {
            if (!mouseHover)
            {
                LinearGradientBrush gradientBrush =
                new LinearGradientBrush(Color.FromRgb(225, 191, 191),
                                        Color.FromRgb(249, 241, 241),
                                        new Point(0.5, 0),
                                        new Point(0.5, 1));

                label.Background = gradientBrush;
            }

            if (mouseHover)
            {
                LinearGradientBrush gradientBrush =
                new LinearGradientBrush(Color.FromRgb(225, 191, 191),
                                        Color.FromRgb(255, 220, 220),
                                        new Point(0.5, 0),
                                        new Point(0.5, 1));

                label.Background = gradientBrush;
            }
        }

        private void Label_button1_MouseEnter(object sender, MouseEventArgs e)
        {
            mouseHover = true;
            ChangeGradientBrush(label_button1);
        }

        private void Label_button1_MouseLeave(object sender, MouseEventArgs e)
        {
            mouseHover = false;
            ChangeGradientBrush(label_button1);
        }

        private void Label_button2_MouseEnter(object sender, MouseEventArgs e)
        {
            mouseHover = true;
            ChangeGradientBrush(label_button2);
        }

        private void Label_button2_MouseLeave(object sender, MouseEventArgs e)
        {
            mouseHover = false;
            ChangeGradientBrush(label_button2);
        }

        private void Label_button3_MouseEnter(object sender, MouseEventArgs e)
        {
            mouseHover = true;
            ChangeGradientBrush(label_button3);
        }

        private void Label_button3_MouseLeave(object sender, MouseEventArgs e)
        {
            mouseHover = false;
            ChangeGradientBrush(label_button3);
        }

        private void Label_button4_MouseEnter(object sender, MouseEventArgs e)
        {
            mouseHover = true;
            ChangeGradientBrush(label_button4);
        }

        private void Label_button4_MouseLeave(object sender, MouseEventArgs e)
        {
            mouseHover = false;
            ChangeGradientBrush(label_button4);
        }


        // TEXTBLOCK BACK TO MAIN MENU
        private void TextBlock_backToMainMenu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            bool goBack = true;

            if (encryptionMode == true && encryptionSaved == false && keySaved != false
                && textBox_input.Text != startText_textBoxInputEncryption && textBox_input.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The encrypted text has not been saved yet. Are you sure you want to go back to the main menu now?",
                                     "Back to main menu", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    goBack = true;
                }

                if (result == MessageBoxResult.No)
                {
                    goBack = false;
                }
            }

            if (encryptionMode == true && keySaved == false && encryptionSaved != false
                && textBox_key.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The encryption key has not been saved yet. Are you sure you want to go back to the main menu now?",
                                     "Back to main menu", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    goBack = true;
                }

                if (result == MessageBoxResult.No)
                {
                    goBack = false;
                }
            }

            if (encryptionMode == true && encryptionSaved == false && keySaved == false
                && textBox_input.Text != startText_textBoxInputEncryption && textBox_input.Text != ""
                && textBox_key.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The encrypted text and the encryption key have not been saved yet. Are you sure you want to go back to the main menu now?",
                                     "Back to main menu", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    goBack = true;
                }

                if (result == MessageBoxResult.No)
                {
                    goBack = false;
                }
            }

            if (decryptionMode == true && decryptionSaved == false
                && textBox_input.Text != startText_textBoxInputDecryption && textBox_input.Text != ""
                && textBox_output.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The decrypted text has not been saved yet. Are you sure you want to go back to the main menu now?",
                                     "Back to main menu", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    goBack = true;
                }

                if (result == MessageBoxResult.No)
                {
                    goBack = false;
                }
            }

            if (goBack == true)
            {
                textBlock_backToMainMenu.Visibility = Visibility.Collapsed;

                label_chooseEncryptDecrypt.Visibility = Visibility.Visible;

                label_button1.Visibility = Visibility.Visible;
                label_button1.Content = "Encrypt";

                label_button2.Visibility = Visibility.Visible;
                label_button2.Content = "Decrypt";
                Grid.SetRow(label_button2, 1);
                label_button2.Margin = new Thickness(0, 42, 0, 0);

                label_button3.Visibility = Visibility.Collapsed;

                label_button4.Visibility = Visibility.Collapsed;

                image_startscreen.Visibility = Visibility.Visible;

                label_textBoxInput.Visibility = Visibility.Collapsed;

                label_textBoxKey.Visibility = Visibility.Collapsed;

                label_textBoxOutput.Visibility = Visibility.Collapsed;

                textBox_input.Visibility = Visibility.Collapsed;
                textBox_input.Text = "";

                textBox_key.Visibility = Visibility.Collapsed;
                textBox_key.Text = "";

                textBox_output.Visibility = Visibility.Collapsed;
                textBox_output.Text = "";

                // Status update
                encryptionMode = false;
                decryptionMode = false;
            }
            else
            {
                // Ignore
            }
        }

        private void TextBlock_backToMainMenu_MouseEnter(object sender, MouseEventArgs e)
        {
            textBlock_backToMainMenu.Foreground = new SolidColorBrush(Colors.DodgerBlue);
        }

        private void TextBlock_backToMainMenu_MouseLeave(object sender, MouseEventArgs e)
        {
            textBlock_backToMainMenu.Foreground = new SolidColorBrush(Colors.RoyalBlue);
        }

        // TEXTBOX INPUT
        private void TextBox_input_GotMouseCapture(object sender, MouseEventArgs e)
        {
            string text = textBox_input.Text;

            if (text == startText_textBoxInputEncryption && encryptionMode)
            {
                text = "";
                textBox_input.Text = text;
                textBox_input.Foreground = new SolidColorBrush(Colors.Black);
            }

            if (text == startText_textBoxInputDecryption && decryptionMode)
            {
                text = "";
                textBox_input.Text = text;
                textBox_input.Foreground = new SolidColorBrush(Colors.Black);
            }
        }

        private void TextBox_input_LostFocus(object sender, RoutedEventArgs e)
        {
            string text = textBox_input.Text;

            if (text == "" && encryptionMode)
            {
                text = startText_textBoxInputEncryption;
                textBox_input.Text = text;
                textBox_input.Foreground = new SolidColorBrush(Colors.DimGray);
            }

            if (text == "" && decryptionMode)
            {
                text = startText_textBoxInputDecryption;
                textBox_input.Text = text;
                textBox_input.Foreground = new SolidColorBrush(Colors.DimGray);
            }
        }

        // TEXTBOX KEY
        string startText_textBoxKey = "Place encryption key here";

        private void TextBox_key_GotMouseCapture(object sender, MouseEventArgs e)
        {
            string text = textBox_key.Text;

            if (text == startText_textBoxKey && decryptionMode)
            {
                text = "";
                textBox_key.Text = text;
                textBox_key.Foreground = new SolidColorBrush(Colors.Black);
            }
        }

        private void TextBox_key_LostFocus(object sender, RoutedEventArgs e)
        {
            string text = textBox_key.Text;

            if (text == "" && decryptionMode)
            {
                text = startText_textBoxKey;
                textBox_key.Text = text;
                textBox_key.Foreground = new SolidColorBrush(Colors.DimGray);
            }
        }

        // MAIN WINDOW CLOSING: Warning messages
        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (encryptionMode == true && encryptionSaved == false && keySaved != false
                && textBox_input.Text != startText_textBoxInputEncryption && textBox_input.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The encrypted text has not been saved yet. Are you sure you want to close the program now?",
                                     "Close program", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    Application.Current.Shutdown();
                }

                if (result == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }
            }

            if (encryptionMode == true && keySaved == false && encryptionSaved != false
                && textBox_key.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The encryption key has not been saved yet. Are you sure you want to close the program now?",
                                     "Close program", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    Application.Current.Shutdown();
                }

                if (result == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }
            }

            if (encryptionMode == true && encryptionSaved == false && keySaved == false
                && textBox_input.Text != startText_textBoxInputEncryption && textBox_input.Text != ""
                && textBox_key.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The encrypted text and the encryption key have not been saved yet. Are you sure you want to close the program now?",
                                     "Close program", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    Application.Current.Shutdown();
                }

                if (result == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }
            }

            if (decryptionMode == true && decryptionSaved == false
                && textBox_input.Text != startText_textBoxInputDecryption && textBox_input.Text != ""
                && textBox_output.Text != "")
            {
                MessageBoxResult result =
                     MessageBox.Show("The decrypted text has not been saved yet. Are you sure you want to close the program now?",
                                     "Close program", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    Application.Current.Shutdown();
                }

                if (result == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }
            }
        }
    }
}