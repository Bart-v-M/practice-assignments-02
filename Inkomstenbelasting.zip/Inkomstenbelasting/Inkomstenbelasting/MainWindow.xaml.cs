﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Inkomstenbelasting
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            label_amountDue.Visibility = Visibility.Hidden;
            label_boxAmountDue.Visibility = Visibility.Hidden;
            label_euroSign2.Visibility = Visibility.Hidden;
            border_boxAmountDue.Visibility = Visibility.Hidden;
        }

        // CALCULATE AMOUNT DUE
        bool inputIsCorrect = true;
        double taxableIncome;
        double taxAllowance; double part1Allowance; double part2Allowance;
        double taxableAmount;
        double amountDue;

        private void CalculateAmountDue()
        {
            // Preset
            inputIsCorrect = true;

            // Check input in inputbox for taxable income 
            string amount = textBox_taxableIncome.Text.Replace(".", "");
            string allowedChars = "0123456789,";
            char[] arrayOfAllowedChars = allowedChars.ToCharArray();

            int count = 0;

            if (amount == "")
            {
                MessageBox.Show("Voer een geldbedrag in.", "Geen invoer");
                inputIsCorrect = false;
            }

            if (inputIsCorrect)
            {
                foreach (char c in amount)
                {
                    if (!arrayOfAllowedChars.Contains(c))
                    {
                        //textBox_taxableIncome.Text = ""; // Clear text (optional)
                        MessageBox.Show("Voer een correct geldbedrag in.", "Ongeldige invoer");
                        inputIsCorrect = false;
                        break;
                    }

                    if (c == ',')
                    {
                        count++;

                        if (count > 1)
                        {
                            //textBox_taxableIncome.Text = ""; // Clear text (optional)
                            MessageBox.Show("Voer een correct geldbedrag in.", "Ongeldige invoer");
                            inputIsCorrect = false;
                            break;
                        }
                    }
                }
            }

            // Check if a tariff group is selected or not
            if (inputIsCorrect)
            {
                if (tariffGroupSelection.IsSelected)
                {
                    MessageBox.Show("Selecteer een tariefgroep.", "Invoer tariefgroep");
                    inputIsCorrect = false;
                }
            }

            // Calculate amount due if input is correct
            if (inputIsCorrect)
            {
                // Replace comma by dot
                amount = amount.Replace(',', '.');

                // Convert string to double
                taxableIncome = Convert.ToDouble(amount);

                // CALCULATE TAX ALLOWANCE
                // Part 1 of tax allowance, depending on tariff group
                if (tariffGroup1.IsSelected) { part1Allowance = 419; }
                if (tariffGroup2.IsSelected) { part1Allowance = 8799; }
                if (tariffGroup3.IsSelected) { part1Allowance = 17179; }
                if (tariffGroup4.IsSelected) { part1Allowance = 15503; }
                if (tariffGroup5.IsSelected) { part1Allowance = 15503; }

                // Part 2 of tax allowance, depending on taxable income 
                part2Allowance = 0.12 * taxableIncome;
                if (part2Allowance > 6704)  // maximum allowance fee, based on taxable income
                {
                    part2Allowance = 6704;  
                }
                if (part2Allowance <= 6704)
                {
                    // Ignore
                }

                // Calculate total tax allowance
                taxAllowance = part1Allowance + part2Allowance;

                // CALCULATE TAXABLE AMOUNT
                taxableAmount = taxableIncome - taxAllowance;

                // Condition: taxable amount cannot be negative
                if (taxableAmount < 0)
                {
                    taxableAmount = 0;
                }
                else
                {
                    // Ignore
                }
                
                // Tax brackets and rates
                double maxBracket1 = 8000;
                double maxBracket2 = 25000;
                double maxBracket3 = 54000;

                double rateBracket1 = 0.3575;
                double rateBracket2 = 0.3705;
                double rateBracket3 = 0.50;
                double rateBracket4 = 0.60;

                // CALCULATE AMOUNT DUE
                // If highest bracket is 1st bracket
                if (taxableAmount <= maxBracket1)
                {
                    amountDue = taxableAmount * rateBracket1;                           // bracket 1
                }

                // If highest bracket is 2nd bracket
                if (taxableAmount > maxBracket1 
                    && taxableAmount <= maxBracket2)
                {
                    amountDue = (maxBracket1 * rateBracket1)                            // bracket 1
                                + ((taxableAmount - maxBracket1) * rateBracket2);       // bracket 2
                }

                // If highest bracket is 3rd bracket
                if (taxableAmount > maxBracket2
                    && taxableAmount <= maxBracket3)
                {
                    amountDue = (maxBracket1 * rateBracket1)                            // bracket 1
                                + ((maxBracket2 - maxBracket1) * rateBracket2)          // bracket 2
                                + ((taxableAmount - maxBracket2) * rateBracket3);       // bracket 3
                }

                // If highest bracket is 4th bracket
                if (taxableAmount > maxBracket3)
                {
                    amountDue = (maxBracket1 * rateBracket1)                            // bracket 1
                                + ((maxBracket2 - maxBracket1) * rateBracket2)          // bracket 2
                                + ((maxBracket3 - maxBracket2) * rateBracket3)          // bracket 3
                                + ((taxableAmount - maxBracket3) * rateBracket4);       // bracket 4
                }

                // Convert double to int
                int result = Convert.ToInt32(amountDue);

                // Convert int to string, set string format with thousands separator and show result in box
                label_boxAmountDue.Content = string.Format(new CultureInfo("nl-NL"), "{0:n0}", result);

                // Make visible label and box
                label_amountDue.Visibility = Visibility.Visible;
                label_boxAmountDue.Visibility = Visibility.Visible;
                label_euroSign2.Visibility = Visibility.Visible;
                border_boxAmountDue.Visibility = Visibility.Visible;

                // Delete dots first (replace by empty string), then replace comma by dot.
                double input = Convert.ToDouble(textBox_taxableIncome.Text.Replace(".", "").Replace(',', '.'));

                // Add thousands separator also to taxable income box
                textBox_taxableIncome.Text = string.Format(new CultureInfo("nl-NL"), "{0:n0}", input);
            }
        }


        // Maximum input
        private void TextBox_taxableIncome_TextChanged(object sender, TextChangedEventArgs e)
        {
            string amount = textBox_taxableIncome.Text;
            
            // Maximum input reached
            if (amount.Length > 12)
            {
                textBox_taxableIncome.Text = amount.Remove(amount.Length - 1, 1);
                textBox_taxableIncome.SelectionStart = textBox_taxableIncome.Text.Length;
                MessageBox.Show("U heeft het maximum aantal tekens voor de invoer van uw belastbaar inkomen bereikt.",
                                "Maximum aantal tekens bereikt");
            }
        }


        // Mousedown actions calculate button
        private void Label_calculateButton_MouseDown(object sender, MouseButtonEventArgs e)
        { CalculateAmountDue(); }

        private void Border_calculateButton_MouseDown(object sender, MouseButtonEventArgs e)
        { CalculateAmountDue(); }


        // Mousecapture and lost focus actions
        private void TextBox_taxableIncome_GotMouseCapture(object sender, MouseEventArgs e)
        {
            textBox_taxableIncome.CaretBrush = new SolidColorBrush(Colors.Black);
            textBox_taxableIncome.Text = textBox_taxableIncome.Text.Replace(".", "");
            textBox_taxableIncome.SelectionStart = textBox_taxableIncome.Text.Length;
        }

        private void TextBox_taxableIncome_LostFocus(object sender, RoutedEventArgs e)
        { textBox_taxableIncome.CaretBrush = new SolidColorBrush(Colors.White); }

        private void ComboBox_tariffGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!tariffGroupSelection.IsSelected)
            {
                comboBox_tariffGroup.Foreground = new SolidColorBrush(Colors.Black);
                tariffGroupSelection.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                comboBox_tariffGroup.Foreground = new SolidColorBrush(Colors.Gray);
            }
        }

        private void ComboBox_tariffGroup_GotMouseCapture(object sender, MouseEventArgs e)
        {
            // Remove caretbrush textbox
            textBox_taxableIncome.CaretBrush = new SolidColorBrush(Colors.White);

            // Change foreground colors combobox items
            tariffGroup1.Foreground = new SolidColorBrush(Colors.Black);
            tariffGroup2.Foreground = new SolidColorBrush(Colors.Black);
            tariffGroup3.Foreground = new SolidColorBrush(Colors.Black);
            tariffGroup4.Foreground = new SolidColorBrush(Colors.Black);
            tariffGroup5.Foreground = new SolidColorBrush(Colors.Black);
            tariffGroupSelection.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void ComboBox_tariffGroup_LostFocus(object sender, RoutedEventArgs e)
        {
            // Change foreground color combobox item 'tariffGroupSelection'
            tariffGroupSelection.Foreground = new SolidColorBrush(Colors.Gray);
        }
    }
}