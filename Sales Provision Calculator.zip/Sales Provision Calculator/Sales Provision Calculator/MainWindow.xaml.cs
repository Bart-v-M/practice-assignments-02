﻿using System;
using System.Globalization;
using System.Linq;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Sales_Provision_Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DetermineMonthAtStartProgram();
        }

        // DETERMINE MONTH IN PAGE TITLE
        DateTime date;
        private void DetermineMonthAtStartProgram()
        {
            // set startdate in title
            DateTime dateMonthAgo = DateTime.Now.AddMonths(-1);
            date = dateMonthAgo;
            textBlock_title.Text = "Employee provision " + date.ToString("Y");
        }


        // GO BACK ONE MONTH IN TITLE
        private void TextBlock_goBackOneMonth_MouseDown(object sender, MouseButtonEventArgs e)
        {
            date = date.AddMonths(-1);
            textBlock_title.Text = "Employee provision " + date.ToString("Y");

            // Set minimum date
            DateTime minimumDate = DateTime.Now.AddYears(-5);
            if (date < minimumDate)
            {
                date = minimumDate;
                textBlock_title.Text = "Employee provision " + DateTime.Now.ToString("Y");
                SystemSounds.Beep.Play();
            }
        }

        // GO FORWARD ONE MONTH IN TITLE
        private void TextBlock_goForwardOneMonth_MouseDown(object sender, MouseButtonEventArgs e)
        {
            date = date.AddMonths(1);
            textBlock_title.Text = "Employee provision " + date.ToString("Y");

            // Set maximum date to current month
            if (date >= DateTime.Now)
            {
                date = DateTime.Now;
                textBlock_title.Text = "Employee provision " + DateTime.Now.ToString("Y");
                SystemSounds.Beep.Play();
            }
        }

        // CALCULATE BUTTON
        private void Label_calculateButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            CalculateProvision();
        }

        // CALCULATE PROVISION
        int quantitySoldInMonth;
        double provisionPerUnitSoldInMonth = 4.00;
        double provisionUnitsSoldInMonth;

        double salesRevenueInMonth;
        double salesPricePerUnit;
        double percentageOfSalesRevenueInMonth = 0.03;
        double provisionOnSalesRevenueInMonth;

        int quantitySoldPastYear; int q; // q is shorthand
        double provisionPercentageUnitsSoldPastYear = 0.00; double p; // p is shorthand

        double totalProvisionInMonth;

        bool inputIsCorrect;

        private void CalculateProvision()
        {
            // Presets
            provisionPercentageUnitsSoldPastYear = 0.00;
            inputIsCorrect = true;
            makingCalculation = true;

            // Check if input quantity sold in month is correct
            string quantityMonth = textBox_quantitySoldInMonth.Text.Replace(".", "");
            string quantityYear = textBox_quantitySoldPastYear.Text.Replace(".", "");
            string allowedChars = "0123456789";
            char[] arrayOfAllowedChars = allowedChars.ToCharArray();

            if (quantityMonth == "")
            {
                SystemSounds.Beep.Play();
                MessageBox.Show("No input for quantity sold in month.", "No input");
                inputIsCorrect = false;
            }

            if (quantityMonth.Length > 7 && inputIsCorrect)
            {
                SystemSounds.Beep.Play();
                MessageBox.Show("Maximum input reached for quantity sold in month.", "Maximum input");
                inputIsCorrect = false;
            }

            if (inputIsCorrect)
            {
                foreach (char c in quantityMonth)
                {
                    if (!arrayOfAllowedChars.Contains(c))
                    {
                        textBox_quantitySoldInMonth.Text = "";
                        SystemSounds.Beep.Play();
                        MessageBox.Show("Invalid input for quantity sold in month.", "Invalid input");
                        inputIsCorrect = false;
                        break;
                    }
                }
            }

            // Check if input sales price per unit is correct
            string salesPrice = textBox_salesPricePerUnit.Text.Replace(".", ""); ;
            allowedChars = "0123456789.,";
            arrayOfAllowedChars = allowedChars.ToCharArray();

            int count = 0;

            if (salesPrice == "" && inputIsCorrect)
            {
                SystemSounds.Beep.Play();
                MessageBox.Show("No input for salesprice.", "No input");
                inputIsCorrect = false;
            }

            if (salesPrice.Length > 9 && inputIsCorrect)
            {
                SystemSounds.Beep.Play();
                MessageBox.Show("Maximum input reached for sales price.", "Maximum input");
                inputIsCorrect = false;
            }

            if (inputIsCorrect)
            {
                foreach (char c in salesPrice)
                {
                    if (!arrayOfAllowedChars.Contains(c))
                    {
                        textBox_salesPricePerUnit.Text = "";
                        SystemSounds.Beep.Play();
                        MessageBox.Show("Invalid input for sales price per unit.", "Invalid input");
                        inputIsCorrect = false;
                        break;
                    }

                    if (c == '.' || c == ',')
                    {
                        count++;

                        if (count > 1)
                        {
                            textBox_salesPricePerUnit.Text = "";
                            SystemSounds.Beep.Play();
                            MessageBox.Show("Invalid input for sales price per unit.", "Invalid input");
                            inputIsCorrect = false;
                            break;
                        }
                    }
                }
            }

            // Check if input quantity sold past year is correct
            if (quantityYear == "" && inputIsCorrect)
            {
                SystemSounds.Beep.Play();
                MessageBox.Show("No input for quantity sold past twelve months.", "No input");
                inputIsCorrect = false;
            }

            if (quantityYear.Length > 9 && inputIsCorrect)
            {
                SystemSounds.Beep.Play();
                MessageBox.Show("Maximum input reached for quantity sold past twelve months.", "Maximum input");
                inputIsCorrect = false;
            }

            if (inputIsCorrect)
            {
                foreach (char c in quantityYear)
                {
                    if (!arrayOfAllowedChars.Contains(c))
                    {
                        textBox_quantitySoldPastYear.Text = "";
                        SystemSounds.Beep.Play();
                        MessageBox.Show("Invalid input for quantity sold past 12 months.", "Invalid input");
                        inputIsCorrect = false;
                        break;
                    }
                }
            }

            // Actual calculation of provision
            if (inputIsCorrect)
            {
                // Provision on units sold in month
                quantitySoldInMonth = Convert.ToInt32(quantityMonth);
                provisionUnitsSoldInMonth = quantitySoldInMonth * provisionPerUnitSoldInMonth;

                // Provision on sales revenue generated in month
                salesPricePerUnit = Convert.ToDouble(salesPrice.Replace(',', '.'));
                salesRevenueInMonth = quantitySoldInMonth * salesPricePerUnit;
                provisionOnSalesRevenueInMonth = salesRevenueInMonth * percentageOfSalesRevenueInMonth;

                // Extra provision based on quantity sold in the past year
                quantitySoldPastYear = Convert.ToInt32(quantityYear);
                q = quantitySoldPastYear;
                p = provisionPercentageUnitsSoldPastYear;

                if (q >= 1000) { p += 0.01; }
                if (q >= 2000) { p += 0.01; }
                if (q >= 3000) { p += 0.01; }
                if (q >= 4000) { p += 0.01; }
                if (q >= 5000) { p += 0.01; }
                if (q >= 6000) { p += 0.01; }
                if (q >= 7000) { p += 0.01; }
                if (q >= 8000) { p += 0.01; }
                if (q >= 9000) { p += 0.01; }
                if (q >= 10000) { p += 0.01; }

                if (q >= 11000) { p += 0.015; }
                if (q >= 12000) { p += 0.015; }
                if (q >= 13000) { p += 0.015; }
                if (q >= 14000) { p += 0.015; }
                if (q >= 15000) { p += 0.015; }
                if (q >= 16000) { p += 0.015; }
                if (q >= 17000) { p += 0.015; }
                if (q >= 18000) { p += 0.015; }
                if (q >= 19000) { p += 0.015; }
                if (q >= 20000) { p += 0.015; }

                if (q >= 21000) { p += 0.02; }
                if (q >= 22000) { p += 0.02; }
                if (q >= 23000) { p += 0.02; }
                if (q >= 24000) { p += 0.02; }
                if (q >= 25000) { p += 0.02; }
                if (q >= 26000) { p += 0.02; }
                if (q >= 27000) { p += 0.02; }
                if (q >= 28000) { p += 0.02; }
                if (q >= 29000) { p += 0.02; }
                if (q >= 30000) { p += 0.02; }
                if (q >= 31000) { p += 0.02; }
                if (q >= 32000) { p += 0.02; }
                if (q >= 33000) { p += 0.02; }
                if (q >= 34000) { p += 0.02; }
                if (q >= 35000) { p += 0.02; }

                quantitySoldPastYear = q;
                provisionPercentageUnitsSoldPastYear = p;

                // Maximum provision percentage on units sold past year
                if (provisionPercentageUnitsSoldPastYear > 0.5) { provisionPercentageUnitsSoldPastYear = 0.5; }

                // Total provision in month
                totalProvisionInMonth = 
                    (provisionUnitsSoldInMonth + provisionOnSalesRevenueInMonth) * (1 + provisionPercentageUnitsSoldPastYear);

                // Show amount on screen
                label_earnedProvisionAmount.Content =
                    totalProvisionInMonth.ToString("C", CultureInfo.GetCultureInfo("nl-NL"));
                label_earnedProvisionAmount.FontSize = 36;

                // Change fontsize if amount becomes longer
                if (totalProvisionInMonth.ToString().Length > 9) { label_earnedProvisionAmount.FontSize = 32; }
                if (totalProvisionInMonth.ToString().Length > 13) { label_earnedProvisionAmount.FontSize = 28; }
                if (totalProvisionInMonth.ToString().Length > 17) { label_earnedProvisionAmount.FontSize = 24; }
                if (totalProvisionInMonth.ToString().Length > 23) { label_earnedProvisionAmount.FontSize = 20; }
                if (totalProvisionInMonth.ToString().Length > 26) { label_earnedProvisionAmount.FontSize = 18; }

                // Show first name of salesperson in textBox_earnedProvision
                string nameSalesPerson = textBox_nameSalesPerson.Text;
                string firstName;

                if (nameSalesPerson.Contains(' '))
                {
                    firstName = nameSalesPerson.Remove(nameSalesPerson.IndexOf(' '));
                }
                else
                {
                    firstName = nameSalesPerson;
                }

                label_earnedProvision.Content = "Earned provision " + firstName + ":";
                label_earnedProvision.FontSize = 36;

                // Change fontsize if namelength becomes longer
                if (firstName.Length > 9) { label_earnedProvision.FontSize = 32; }
                if (firstName.Length > 13) { label_earnedProvision.FontSize = 28; }
                if (firstName.Length > 17) { label_earnedProvision.FontSize = 24; }
                if (firstName.Length > 19) { label_earnedProvision.FontSize = 22; }
                if (firstName.Length > 23) { label_earnedProvision.FontSize = 20; }
                if (firstName.Length > 26) { label_earnedProvision.FontSize = 18; }

                // Add dots as thousands separators, and comma as as decimal separator
                textBox_quantitySoldInMonth.Text = 
                    string.Format(CultureInfo.GetCultureInfo("nl-NL"), "{0:n0}", quantitySoldInMonth);
                textBox_salesPricePerUnit.Text =
                    string.Format(CultureInfo.GetCultureInfo("nl-NL"), "{0:n}", salesPricePerUnit);
                textBox_quantitySoldPastYear.Text = 
                    string.Format(CultureInfo.GetCultureInfo("nl-NL"), "{0:n0}", quantitySoldPastYear);

                // Make caretbrush invisible
                textBox_nameSalesPerson.CaretBrush = new SolidColorBrush(Colors.Honeydew);
                textBox_quantitySoldInMonth.CaretBrush = new SolidColorBrush(Colors.Honeydew);
                textBox_salesPricePerUnit.CaretBrush = new SolidColorBrush(Colors.Honeydew);
                textBox_quantitySoldPastYear.CaretBrush = new SolidColorBrush(Colors.Honeydew);

                // Reset
                makingCalculation = false;
            }
        }

        // GOT MOUSE CAPTURE METHODS
        private void TextBox_nameSalesPerson_GotMouseCapture(object sender, MouseEventArgs e)
        {
            textBox_nameSalesPerson.CaretBrush = new SolidColorBrush(Colors.Black);
        }

        private void TextBox_quantitySoldInMonth_GotMouseCapture(object sender, MouseEventArgs e)
        {
            textBox_quantitySoldInMonth.CaretBrush = new SolidColorBrush(Colors.Black);
            textBox_quantitySoldInMonth.Text = textBox_quantitySoldInMonth.Text.Replace(".", "");
            textBox_quantitySoldInMonth.SelectionStart = textBox_quantitySoldInMonth.Text.Length;
        }

        private void TextBox_salesPricePerUnit_GotMouseCapture(object sender, MouseEventArgs e)
        {
            textBox_salesPricePerUnit.CaretBrush = new SolidColorBrush(Colors.Black);
            textBox_salesPricePerUnit.Text = textBox_salesPricePerUnit.Text.Replace(".", "");
            textBox_salesPricePerUnit.SelectionStart = textBox_salesPricePerUnit.Text.Length;
        }

        private void TextBox_quantitySoldPastYear_GotMouseCapture(object sender, MouseEventArgs e)
        {
            textBox_quantitySoldPastYear.CaretBrush = new SolidColorBrush(Colors.Black);
            textBox_quantitySoldPastYear.Text = textBox_quantitySoldPastYear.Text.Replace(".", "");
            textBox_quantitySoldPastYear.SelectionStart = textBox_quantitySoldPastYear.Text.Length;
        }

        // SALES PRICE INPUT: CHANGE DOT TO COMMA
        bool makingCalculation = false;
        private void TextBox_salesPricePerUnit_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (makingCalculation == false)
            {
                if (textBox_salesPricePerUnit.Text.Contains('.'))
                {
                    textBox_salesPricePerUnit.Text = textBox_salesPricePerUnit.Text.Replace('.', ',');
                    textBox_salesPricePerUnit.SelectionStart = textBox_salesPricePerUnit.Text.Length;
                }    
            }
        }
    }       
}
