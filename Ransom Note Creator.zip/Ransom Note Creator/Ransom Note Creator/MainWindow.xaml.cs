﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Ransom_Note_Creator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            RemoveLetterLabels();
            CreateNewRansomNote();
            programStart = false;
        }

        // PROGRAM START
        bool programStart = true;

        // PROGRAM TITLE
        string title = "Ransom Note Creator";

        // RANDOM
        Random random = new Random();

        // CREATE NEW RANSOM NOTE METHOD
        private void CreateNewRansomNote()
        {
            // Create letter labels
            if (programStart == true)
            {
                CreateLetterLabels(title);
            }

            if (programStart == false)
            {
                // Clearing actions first
                RemoveLetterLabels();
                listOfLetterLabels.Clear();
                randomWidth.Clear();
                randomHeight.Clear();
                listOfChars.Clear();

                CreateLetterLabels(textBox.Text);
            }
           
            // Random selection of font family and foreground and background colors, plus letter rotation effect
            foreach (Label label in listOfLetterLabels)
            {
                SelectFontFamilyAtRandom(label);
                SelectForegroundAndBackgroundColorAtRandom(label);
                RotateLetterLabelAtRandom(label);
            }
        }

        // REMOVE LETTER LABELS
        private void RemoveLetterLabels()
        {
            // Set visibility for each label to 'Visibility.Collapsed'
            foreach (Label label in listOfLetterLabels)
            {
                label.Visibility = Visibility.Collapsed;
            }
        }

        // AUTOMATIC LETTER LABEL CREATOR
        List<char> listOfChars = new List<char>();
        List<Label> listOfLetterLabels = new List<Label>();
        List<int> randomWidth = new List<int>();
        List<int> randomHeight = new List<int>();
        List<int> randomFontSize = new List<int>();
       
        // Create letter labels
        private void CreateLetterLabels(string text)
        {
            // String text to list of characters
            listOfChars = text.ToCharArray().ToList();

            // Make sure that words are kept at the same line (insert extra spaces if not)
            string[] split;
            string firstPart;
            string lastPart;

            // first line to second line
            if (text.Length >= 26 && text.Contains(' ')
                && listOfChars[24] != ' ' && listOfChars[25] != ' ')
            {
                text = text.Substring(0, 25);
                split = text.Split(' ');
                firstPart = string.Join(" ", split.Take(split.Length - 1));
                lastPart = split.Last();

                do
                {
                    firstPart += " ";
                    listOfChars.Insert(firstPart.Length, ' ');
                }
                while (listOfChars[24] != ' ' && listOfChars[25] != ' ');
            }
            else
            {
                // Ignore
            }

            // Remove empty character at start of second line, if it pops up
            if (text.Length >= 27 && listOfChars[25] == ' ' && listOfChars[26] != ' ')
            {
                do
                {
                    listOfChars.RemoveAt(25);
                }
                while (listOfChars[25] == ' ' && listOfChars[26] != ' ');
            }
            else
            {
                // Ignore
            }

            // Make labels
            if (listOfChars.Count <= 50)
            {
                // Initialization of random numbers
                int randomNr1;
                int randomNr2;
                int randomNr3;

                // Label for each character, plus assignment of random numbers
                foreach (char c in listOfChars)
                {
                    // Creation of new label foreach character in text
                    Label label = new Label();
                    listOfLetterLabels.Add(label);

                    // Assignment of random number to font size
                    randomNr1 = random.Next(24, 32);
                    randomFontSize.Add(randomNr1);

                    // Assignment of random number to label width
                    randomNr2 = random.Next(28, 34);
                    randomWidth.Add(randomNr2);

                    // Assignment of random number to label height
                    randomNr3 = random.Next(42, 59);
                    randomHeight.Add(randomNr3);
                }

                // Set label properties
                for (int i = 0; i < listOfLetterLabels.Count; i++)
                {
                    listOfLetterLabels[i].Content = listOfChars[i];
                    listOfLetterLabels[i].FontSize = randomFontSize[i];
                    listOfLetterLabels[i].Width = randomWidth[i];
                    listOfLetterLabels[i].Height = randomHeight[i];
                    listOfLetterLabels[i].Padding = new Thickness(0, 0, 0, 0);
                    listOfLetterLabels[i].HorizontalAlignment = HorizontalAlignment.Left;
                    listOfLetterLabels[i].VerticalAlignment = VerticalAlignment.Top;
                    listOfLetterLabels[i].HorizontalContentAlignment = HorizontalAlignment.Center;
                    listOfLetterLabels[i].VerticalContentAlignment = VerticalAlignment.Center;

                    // Set standard distance between lines
                    int lineDistance = 40;

                    // Start of new line
                    if (i == 0)
                    {
                        listOfLetterLabels[0].Margin = new Thickness
                            (0,
                             0,
                             0,
                             0);
                    }
                    if (i == 25)
                    {
                        listOfLetterLabels[25].Margin = new Thickness
                            (0,
                             listOfLetterLabels[0].Height + lineDistance,
                             0,
                             0);
                    }

                    // Continue current line until...
                    if (i > 0 && i < 25)
                    {
                        int x = random.Next(0, 8);

                        listOfLetterLabels[i].Margin = new Thickness
                            (listOfLetterLabels[i - 1].Margin.Left + listOfLetterLabels[i - 1].Width + x,
                             0,
                             0,
                             0);
                    }
                    if (i > 25 && i < 50)
                    {
                        int x = random.Next(0, 8);

                        listOfLetterLabels[i].Margin = new Thickness
                            (listOfLetterLabels[i - 1].Margin.Left + listOfLetterLabels[i - 1].Width + x,
                             listOfLetterLabels[0].Height + lineDistance,
                             0,
                             0);
                    }

                    // Set row and column
                    Grid.SetRow(listOfLetterLabels[i], 1);
                    Grid.SetColumn(listOfLetterLabels[i], 1);

                    // Add label(s) to grid
                    myGrid.Children.Add(listOfLetterLabels[i]);
                }
            }
            else
            {
                // Message that maximum number of lines(2) is reached
                SystemSounds.Beep.Play();
                MessageBox.Show("You've reached the maximum input of 2 lines.", "Maximum input reached");
            }

        }

        // SELECT LETTER LABEL FONT FAMILY
        private void SelectFontFamilyAtRandom(Label label)
        {
            // List of font families the program uses
            List<string> listOfFontFamilies = new List<string>
            {
                "Arial", "Arial Black", "Calibri", "Cambria", "Comic Sans MS", "Constantia", "Courier New",
                "Franklin Gothic Medium", "Gabriola", "Georgia", "Global Monospace", "Global Sans Serif",
                "Global Serif", "Impact", "Ink Free", "Javanese Text", "Leelawadee UI", "Lucida Console",
                "Malgun Gothic", "MS Gothic", "MV Boli", "Palatino Linotype", "Segoe Script", "Segoe UI Black",
                "SimSun", "Tahoma", "Times New Roman", "Trebuchet MS", "Verdana"
            };

            // Select a number at random
            int randomNr = random.Next(0, listOfFontFamilies.Count);

            // Select font family
            label.FontFamily = new FontFamily(listOfFontFamilies[randomNr]);
        }

        // SELECT LETTER LABEL FOREGROUND & BACKGROUND COLOR
        private void SelectForegroundAndBackgroundColorAtRandom(Label label) 
        {
            // List of light colors the program uses
            List<string> listOfLightColors = new List<string>
            {
                "AliceBlue", "AntiqueWhite", "Aquamarine", "Azure", "Beige", "Bisque", "BlanchedAlmond",
                "BurlyWood", "Cornsilk", "FloralWhite", "Gainsboro", "GhostWhite", "Honeydew", "Ivory",
                "Lavender", "LavenderBlush", "LemonChiffon", "LightCyan", "LightGoldenrodYellow",
                "LightGray", "LightYellow", "Linen", "MintCream", "MistyRose", "Moccasin",
                "NavajoWhite", "OldLace", "PapayaWhip", "PeachPuff", "SeaShell", "Wheat"
            };

            // List of bright colors the program uses
            List<string> listOfBrightColors = new List<string>
            {
                "Aqua","Blue","BlueViolet", "Chartreuse", "Chocolate", "Coral", "CornflowerBlue",
                "Crimson", "Cyan", "DarkOrange", "DarkMagenta", "DarkOrchid", "DarkViolet", "DeepPink",
                "DeepSkyBlue", "DodgerBlue", "Fuchsia", "Gold", "GreenYellow", "HotPink", "LawnGreen",
                "LightCoral", "LightGreen", "LightPink", "LightSalmon", "Lime", "Magenta", "Orange",
                "OrangeRed", "Orchid", "Red", "Salmon", "SpringGreen", "Tomato", "Turquoise", "Violet",
                "Yellow"
            };

            // List of dark colors the program uses
            List<string> listOfDarkColors = new List<string>
            {
                "CadetBlue", "DarkBlue", "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki",
                "DarkOliveGreen", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray",
                "DimGray", "Firebrick", "ForestGreen", "Gray", "Green", "IndianRed", "Indigo", "Maroon",
                "Navy", "Olive", "Olivedrab", "Purple", "SaddleBrown", "Sienna", "SlateGray"
            };

            // SELECT FOREGROUND COLOR AT RANDOM

            // Select at random if foreground will be in a light, medium or dark color
            int randomNr1 = random.Next(0, 5);

            // Select foreground color (letter color) at random
            int randomNr2;
            Color color;

            // Pick light color
            if (randomNr1 == 0)
            {
                randomNr2 = random.Next(0, listOfLightColors.Count);
                color = (Color)ColorConverter.ConvertFromString(listOfLightColors[randomNr2]);
                label.Foreground = new SolidColorBrush(color);
            }

            // Pick bright color
            if (randomNr1 == 1)
            {
                randomNr2 = random.Next(0, listOfBrightColors.Count);
                color = (Color)ColorConverter.ConvertFromString(listOfBrightColors[randomNr2]);
                label.Foreground = new SolidColorBrush(color);
            }

            // Pick dark color
            if (randomNr1 == 2)
            {
                randomNr2 = random.Next(0, listOfDarkColors.Count);
                color = (Color)ColorConverter.ConvertFromString(listOfDarkColors[randomNr2]);
                label.Foreground = new SolidColorBrush(color);
            }

            // Pick black
            if (randomNr1 == 3)
            {
                label.Foreground = new SolidColorBrush(Colors.Black);
            }

            // Pick white
            if (randomNr1 == 4)
            {
                label.Foreground = new SolidColorBrush(Colors.White);
            }

            // SELECT BACKGROUND COLOR
            int randomNr3;
            int randomNr4;

            // If foreground is a light color or white
            if (randomNr1 == 0 || randomNr1 == 4)
            {
                randomNr3 = random.Next(0, 3);

                // Pick bright color
                if (randomNr3 == 0)
                {
                    randomNr4 = random.Next(0, listOfBrightColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfBrightColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);

                    // Exception(s)
                    if (label.Background == new SolidColorBrush(Colors.Yellow))
                    {
                        label.Background = new SolidColorBrush(Colors.Black);
                    }
                }

                // Pick dark color
                if (randomNr3 == 1)
                {
                    randomNr4 = random.Next(0, listOfDarkColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfBrightColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);
                }

                // Pick black
                if (randomNr3 == 2)
                {
                    label.Background = new SolidColorBrush(Colors.Black);
                }
            }

            // If foreground is a bright color
            if (randomNr1 == 1)
            {
                randomNr3 = random.Next(0, 4);

                // Pick light color
                if (randomNr3 == 0)
                {
                    randomNr4 = random.Next(0, listOfLightColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfLightColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);
                }

                // Pick dark color
                if (randomNr3 == 1)
                {
                    randomNr4 = random.Next(0, listOfDarkColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfDarkColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);
                }

                // Pick black
                if (randomNr3 == 2)
                {
                    label.Background = new SolidColorBrush(Colors.Black);
                }

                // Pick white
                if (randomNr3 == 3)
                {
                    label.Background = new SolidColorBrush(Colors.Transparent);

                    // Exception(s)
                    if (label.Foreground == new SolidColorBrush(Colors.Yellow))
                    {
                        label.Background = new SolidColorBrush(Colors.Black);
                    }
                }
            }

            // If foreground is a dark color
            if (randomNr1 == 2)
            {
                randomNr3 = random.Next(0, 3);

                // Pick light color
                if (randomNr3 == 0)
                {
                    randomNr4 = random.Next(0, listOfLightColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfLightColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);
                }

                // Pick bright color
                if (randomNr3 == 1)
                {
                    randomNr4 = random.Next(0, listOfBrightColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfBrightColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);
                }

                // Pick white
                if (randomNr3 == 2)
                {
                    label.Background = new SolidColorBrush(Colors.Transparent);
                }
            }

            // If foreground is black
            if (randomNr1 == 3)
            {
                randomNr3 = random.Next(0, 3);

                // Pick light color
                if (randomNr3 == 0)
                {
                    randomNr4 = random.Next(0, listOfLightColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfLightColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);
                }

                // Pick bright color
                if (randomNr3 == 1)
                {
                    randomNr4 = random.Next(0, listOfBrightColors.Count);
                    color = (Color)ColorConverter.ConvertFromString(listOfBrightColors[randomNr4]);
                    label.Background = new SolidColorBrush(color);
                }

                // Pick white
                if (randomNr3 == 2)
                {
                    label.Background = new SolidColorBrush(Colors.Gainsboro);
                }
            }

            // Set background to mainwindow background if label content is empty, or if it's a comma or a dot
            string labelText = label.Content.ToString();
            if (labelText == " " || labelText == "" || labelText == "," || labelText == ".")
            {
                label.Foreground = new SolidColorBrush(Colors.Black);
                label.Background = new SolidColorBrush(Colors.Transparent);
            }
        }

        // ROTATE LETTER LABELS AT RANDOM
        private void RotateLetterLabelAtRandom(Label label)
        {
            int randomNr1 = random.Next(-9, 10);
            int randomNr2 = random.Next(-9, 10);
            int randomNr3 = random.Next(-9, 10);

            RotateTransform rotateLabel = new RotateTransform(randomNr1, randomNr2, randomNr3);

            string labelText = label.Content.ToString();
            if (labelText != " " && labelText != "")
            {
                label.RenderTransform = rotateLabel;
            } 
            else
            {
                // Ignore
            }
        }

        // BUTTON CLICK "Create New Ransom Note!"
        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (textBox.Text == "Write your text here" || textBox.Text == "")
            {
                // Ignore
            }
            else
            {
                CreateNewRansomNote();
            }
        }

        // TEXTBOX GOT MOUSE CAPTURE
        private void TextBox_GotMouseCapture(object sender, MouseEventArgs e)
        {
            if (textBox.Text == "Write your text here")
            {
                textBox.Text = "";
            }
            else
            {
                // Ignore
            }     
        }

        // CHECK IF MAXIMUM NUMBER OF CHARACTERS IS REACHED
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBox.Text.Length >= 50)
            {
                SystemSounds.Beep.Play();
                MessageBox.Show("You've reached the maximum input of 50 characters.", "Maximum input reached");
            }
        }
    }
}